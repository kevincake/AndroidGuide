UI控件之复选框控件 CheckBox 的使用方法
CheckBox默认的情况下是未选中的状态，如果想修改这个默认值的话，可以将<checkbox>中的android:checked设置为true或者使用CheckBox.setChecked方法设置都可以实现复选的功能。
###实战案例一：
复选框控件使用，实现当用户去点击确定按钮的时候能弹出用户所选择的这个选项
布局文件：main.xml 
```
<?xml version="1.0" encoding="utf-8"?>
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="fill_parent"
    android:layout_height="fill_parent"
    android:orientation="vertical" >

    <Button 
        android:id="@+id/button"
        android:layout_width="fill_parent"
        android:layout_height="wrap_content"
        android:text="确定" />

</LinearLayout>
```
checkbox.xml
```
public class CheckBoxDemo extends Activity implements OnClickListener {

    private List<CheckBox> checkBoxs = new ArrayList<CheckBox>();

    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // 注释掉 setContentView，也就是说在Oncreate加载xml的时候我们使用动态加载布局的方式
        // setContentView(R.layout.main);
        String[] checkBoxTest = new String[] {
                "你是学生吗？", "是否喜欢Android？", "你喜欢旅游吗？", "打算出国吗？"
        };
        
        /*
         * 查看android api的Activity 中的 getLayoutInflater()方法 ：public LayoutInflater getLayoutInflater ()
         * 返回的是 LayoutInflater 这个就是Android中的动态加载布局
         * 查看 LayoutInflater，它表示会加载一个布局xml文件到相应的视图对象中，它主要使用inflate()方法来实现的
         * public View inflate (int resource, ViewGroup root)
         * 它会从指定的xml资源中加载一个新的视图布局，并且填充它的父视图，如果没有父视图的话，root参数设置为null。
         */
        
        LinearLayout linearLayout = (LinearLayout) getLayoutInflater().inflate(R.layout.main, null);
        //给指定的checkbox赋值
        for(int i = 0; i < checkBoxTest.length; i++) {
            //先获得checkBox.xml的对象
            CheckBox checkBoxLayout = (CheckBox)getLayoutInflater().inflate(R.layout.checkbox, null);
            checkBoxs.add(checkBoxLayout);
            checkBoxs.get(i).setText(checkBoxTest[i]);
            
            //实现了在main主布局中，通过LinearLayout在for循环中添加checkbox。
            linearLayout.addView(checkBoxLayout, i);           
            setContentView(linearLayout);
            
            Button button = (Button)findViewById(R.id.button);
            button.setOnClickListener(this);
        }
    }

    @Override
    public void onClick(View v) {
        // TODO Auto-generated method stub
        //当用户点击按钮的时候，要取出这个布局
        String str = "";
        for(CheckBox checkBox : checkBoxs){
            if(checkBox.isChecked()){
                str += checkBox.getText() + "\n";
            }
        }
        if("".equals(str)){
            str = "你还没有选中选项!!";
        }
        //使用一个提示框来显示用户信息
        new AlertDialog.Builder(this).setMessage(str).setPositiveButton("关闭", null).show();
    }
}
```
程序主要代码：
```
public class CheckBoxDemo extends Activity implements OnClickListener {

    private List<CheckBox> checkBoxs = new ArrayList<CheckBox>();

    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // 注释掉 setContentView，也就是说在Oncreate加载xml的时候我们使用动态加载布局的方式
        // setContentView(R.layout.main);
        String[] checkBoxTest = new String[] {
                "你是学生吗？", "是否喜欢Android？", "你喜欢旅游吗？", "打算出国吗？"
        };
        
        /*
         * 查看android api的Activity 中的 getLayoutInflater()方法 ：public LayoutInflater getLayoutInflater ()
         * 返回的是 LayoutInflater 这个就是Android中的动态加载布局
         * 查看 LayoutInflater，它表示会加载一个布局xml文件到相应的视图对象中，它主要使用inflate()方法来实现的
         * public View inflate (int resource, ViewGroup root)
         * 它会从指定的xml资源中加载一个新的视图布局，并且填充它的父视图，如果没有父视图的话，root参数设置为null。
         */
        
        LinearLayout linearLayout = (LinearLayout) getLayoutInflater().inflate(R.layout.main, null);
        //给指定的checkbox赋值
        for(int i = 0; i < checkBoxTest.length; i++) {
            //先获得checkBox.xml的对象
            CheckBox checkBoxLayout = (CheckBox)getLayoutInflater().inflate(R.layout.checkbox, null);
            checkBoxs.add(checkBoxLayout);
            checkBoxs.get(i).setText(checkBoxTest[i]);
            
            //实现了在main主布局中，通过LinearLayout在for循环中添加checkbox。
            linearLayout.addView(checkBoxLayout, i);           
            setContentView(linearLayout);
            
            Button button = (Button)findViewById(R.id.button);
            button.setOnClickListener(this);
        }
    }

    @Override
    public void onClick(View v) {
        // TODO Auto-generated method stub
        //当用户点击按钮的时候，要取出这个布局
        String str = "";
        for(CheckBox checkBox : checkBoxs){
            if(checkBox.isChecked()){
                str += checkBox.getText() + "\n";
            }
        }
        if("".equals(str)){
            str = "你还没有选中选项!!";
        }
        //使用一个提示框来显示用户信息
        new AlertDialog.Builder(this).setMessage(str).setPositiveButton("关闭", null).show();
    }
}
```
程序Demo执行结果：
![](http://img.blog.csdn.net/20130531230546431)</br>
![](http://img.blog.csdn.net/20130531230546431)</br>

出处: <a href="http://blog.csdn.net/ahuier/article/details/9002958">http://blog.csdn.net/ahuier/article/details/9002958</a>