
###前言

　　这篇博客聊一聊在Android下ImageView的使用，在此篇博客中，会讲解到ImageView的一些属性的使用，以及ImageView展示图片的放大、缩小、旋转等操作。最后再讲解一下Android4.0项目中最常用的一个功能，从网络获取图片的示例。本文所有讲解均会附上示例代码，并在最后提供源码下载。

####ImageView

　　ImageView，图像视图，直接继承自View类，它的主要功能是用于显示图片，实际上它不仅仅可以用来显示图片，任何Drawable对象都可以使用ImageView来显示。ImageView可以适用于任何布局中，并且Android为其提供了缩放和着色的一些操作。

　　ImageView的一些常用属性，并且这些属性都有与之对应的getter、setter方法：

- android:adjustViewBounds：设置ImageView是否调整自己的边界来保持所显示图片的长宽比。
- android:maxHeight：设置ImageView的最大高度。
- android:maxWidth：设置ImageView的最大宽度。
- android:scaleType：设置所显示的图片如何缩放或移动以适应ImageView的大小。
- android:src：设置ImageView所显示的Drawable对象的ID。
　　对于android:scaleType属性，因为关于图像在ImageView中的显示效果，所以有如下属性值可以选择：

- matrix：使用matrix方式进行缩放。
- fitXY：横向、纵向独立缩放，以适应该ImageView。
- fitStart:保持纵横比缩放图片，并且将图片放在ImageView的左上角。
- fitCenter：保持纵横比缩放图片，缩放完成后将图片放在ImageView的中央。
- fitEnd：保持纵横比缩放图片，缩放完成后将图片放在ImageView的右下角。
- center：把图片放在ImageView的中央，但是不进行任何缩放。
- centerCrop：保持纵横比缩放图片，以使图片能完全覆盖ImageView。
- centerInside：保持纵横比缩放图片，以使得ImageView能完全显示该图片。
图片基本显示

　　下面通过一个示例效果，来说明一下ImageView是如何显示图片的，再此示例中，需要使用到一个green.png的图片，需要放到Drawable文件夹下，关于Android的资源文件，以后再进行详解。

　　布局代码：
```
<?xml version="1.0" encoding="utf-8"?>
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:orientation="vertical" >

    <TextView
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:text="scaleType:center，未缩放，在ImageView的中心" />

    <ImageView
        android:id="@+id/imageview1"
        android:layout_width="200dp"
        android:layout_height="100dp"
        android:background="#F00"
        android:scaleType="center"
        android:src="@drawable/green" />

    <TextView
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:text="scaleType:fitCenter，按比例缩放" />

    <ImageView
        android:id="@+id/imageview2"
        android:layout_width="300dp"
        android:layout_height="200dp"
        android:background="#FFF"
        android:padding="10dp"
        android:scaleType="fitCenter"
        android:src="@drawable/green" />

</LinearLayout>
```
效果展示：
<br/>![](http://images.cnitblog.com/blog/234895/201307/24130415-5668dc8b6cf549d68f308b408b23de87.x-png)<br/>

####缩放与旋转图片

　　因为ImageView继承自View，所以在代码中设置其大小，可以使用View.setLayoutParams(new LinearLayout.LayoutParams(newWidth,newHeight))方法，这个方法可以直接设定View下的所有控件的外观大小，所以这里也适用于ImageView。

　　而对于ImageView的旋转，这里涉及到一个Matrix类的使用。它表示一个3x3的坐标变换矩阵，可以在这个矩阵内，对其进行变换、旋转操作，它需要通过构造函数显式的初始化之后才可以使用。

　　下面通过一个示例来说明一下图片的放大缩小与旋转的示例，在示例中会提供两个SeekBar，对于SeekBar如果不了解的话，可以参见我的另外一篇博客，Android—UI之Progress。这两个SeekBar一个设置ImageView显示图片的大小，另一个设置旋转的角度。对于图片大小，通过DisplayMetrics设置屏幕的宽度为图像的最大宽度，具体操作在注释中已经写明，这里不在累述。

　　布局代码： 
```
<?xml version="1.0" encoding="utf-8"?>
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:orientation="vertical" >

    <ImageView
        android:id="@+id/imageview3"
        android:layout_width="200dp"
        android:layout_height="150dp"
        android:scaleType="fitCenter"
        android:src="@drawable/green" />

    <TextView
        android:id="@+id/tv1"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:layout_marginTop="10dp"
        android:text="图像宽度：240 图像高度：150" />

    <SeekBar
        android:id="@+id/sbSize"
        android:layout_width="200dp"
        android:layout_height="wrap_content"
        android:layout_marginTop="10dp"
        android:max="240"
        android:progress="120" />

    <TextView
        android:id="@+id/tv2"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:layout_marginTop="10dp"
        android:text="0°" />

    <SeekBar
        android:id="@+id/sbRotate"
        android:layout_width="200dp"
        android:layout_height="wrap_content"
        android:layout_marginTop="10dp"
        android:max="360" />

</LinearLayout>
```
实现代码：
```
package com.bgxt.imageviewdemo;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.graphics.drawable.BitmapDrawable;
import android.os.Bundle;
import android.util.DisplayMetrics;

import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.TextView;

@SuppressLint("NewApi")
public class ChangeImageActivity extends Activity implements
        OnSeekBarChangeListener {
    private int minWidth = 80;
    private ImageView imageView;
    private TextView textview1, textview2;
    Matrix matrix=new Matrix();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_changeimage);

        imageView = (ImageView) findViewById(R.id.imageview3);
        SeekBar seekbar1 = (SeekBar) findViewById(R.id.sbSize);
        SeekBar seekbar2 = (SeekBar) findViewById(R.id.sbRotate);
        textview1 = (TextView) findViewById(R.id.tv1);
        textview2 = (TextView) findViewById(R.id.tv2);

        //获取当前屏幕的尺寸，并设置图片放大的最大尺寸，不能超过屏幕尺寸
        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);
        seekbar1.setMax(dm.widthPixels - minWidth);
        
        seekbar1.setOnSeekBarChangeListener(this);
        seekbar2.setOnSeekBarChangeListener(this);        
    }

    @Override
    public void onProgressChanged(SeekBar seekBar, int progress,
            boolean fromUser) {
        if (seekBar.getId() == R.id.sbSize) {
            //设置图片的大小
            int newWidth=progress+minWidth;
            int newHeight=(int)(newWidth*3/4);
            imageView.setLayoutParams(new LinearLayout.LayoutParams(newWidth, newHeight));
            textview1.setText("图像宽度："+newWidth+"图像高度："+newHeight);
        } else if (seekBar.getId() == R.id.sbRotate){
            //获取当前待旋转的图片
            Bitmap bitmap=BitmapFactory.decodeResource(getResources(), R.drawable.green);
            //设置旋转角度
            matrix.setRotate(progress,30,60);
            //通过待旋转的图片和角度生成新的图片
            bitmap=Bitmap.createBitmap(bitmap,0,0,bitmap.getWidth(),bitmap.getHeight(),matrix,true);
            //绑定图片到控件上
            imageView.setImageBitmap(bitmap);
            textview2.setText(progress+"°");
        }
    }

    @Override
    public void onStartTrackingTouch(SeekBar seekBar) {
        // TODO Auto-generated method stub

    }

    @Override
    public void onStopTrackingTouch(SeekBar seekBar) {
        // TODO Auto-generated method stub

    }

}
```
　　效果展示：
<br/>![](http://images.cnitblog.com/blog/234895/201307/24140222-30e2dbfc85d04b5598c0f5c8fb424b98.x-png)![](http://images.cnitblog.com/blog/234895/201307/24140310-bdc44d689b0f44739bcf265cf0db5e7a.x-png)![](http://images.cnitblog.com/blog/234895/201307/24140322-d5fb371f27b44e6091abb0b7640ceeac.x-png)<br/>

出处:http://www.cnblogs.com/plokmju/p/android__ImageView.html