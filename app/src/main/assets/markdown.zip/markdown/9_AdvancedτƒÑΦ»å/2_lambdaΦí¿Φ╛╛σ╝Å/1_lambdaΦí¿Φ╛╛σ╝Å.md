Java 8新特性.个人感觉能减少不少没必要的格式代码.可以理解为匿名函数

[TOC]
#Lambda
##lambda好处
###bad code
```
Runnable r1 = new Runnable(){      
       @Override
       public void run(){
         System.out.println("Hello world one!");
       }
     };
```
###lambda code
```
Runnable r2 = () -> System.out.println("Hello world two!");
```
昂。其实还有很多，后面我会给大家都列上.接下来我给大家介绍基础
##Lambda语法
```
(param,param,....)->{ body }
```
举个栗子:
```
(int a, int b) -> {  return a + b; }
```
###Lambda 表达式的结构
- 让我们了解一下 Lambda 表达式的结构。
- 一个 Lambda 表达式可以有零个或多个参数
参数的类型既可以明确声明，也可以根据上下文来推断。例如：(int a)与(a)效果相同
- 所有参数需包含在圆括号内，参数之间用逗号相隔。例如：(a, b) 或 (int a, int b) 或 (String a, int b, float c)
空圆括号代表参数集为空。例如：() -> 42
当只有一个参数，且其类型可推导时，圆括号（）可省略。例如：a -> return a*a
- Lambda 表达式的主体可包含零条或多条语句
- 如果 Lambda 表达式的主体只有一条语句，花括号{}可省略。匿名函数的返回类型与该主体表达式一致
如果 Lambda 表达式的主体包含一条以上语句，则表达式必须包含在花括号{}中（形成代码块）。匿名函数的返回类型与代码块的返回类型一致，若没有返回则为空

##Lambda使用日常
###Runnable函数赋值
```
//基础版本
Runnable r1 = new Runnable(){      
       @Override
       public void run(){
         System.out.println("Hello world one!");
       }
     };
//lambda版本
Runnable r2 = () -> System.out.println("Hello world two!");
```
###List遍历
```
//Old way:
List<Integer> list = Arrays.asList(1, 2, 3, 4, 5, 6, 7);
for(Integer n: list) {
   System.out.println(n);
}

//New way:
List<Integer> list = Arrays.asList(1, 2, 3, 4, 5, 6, 7);
list.forEach(n -> System.out.println(n));
```
###Android OnclickListener
```
//之前的写法
btn.setOnClickListener(new View.OnClickListener() {
     @Override
      public void onClick(View v) {
          System.out.println("hello lambda");
          ...
      }
});

//Lambda表达式写法
btn.setsetOnClickListener((View v) -> {
          System.out.println("hello lambda");
          ...
      }
);
```
###Map
```
map.forEach((key, value) -> {
    System.out.println("Key : " + key + " Value : " + value);
});
```
##Lambda动手写

```
函数名返回值去掉.用   ()->{}代替
参数放进().body放进{}.返回值自动 口诀
参小体中返自动....（我自己总结的..）
```
##Android添加Lambda支持
```
buildscript {
  repositories {
     mavenCentral()
  }

  dependencies {
     classpath 'me.tatarka:gradle-retrolambda:2.2.2'
  }
}

// Required because retrolambda is on maven central
repositories {
  mavenCentral()
}

apply plugin: 'com.android.application' //or apply plugin: 'java'
apply plugin: 'retrolambda'

android {
  compileOptions {
    sourceCompatibility JavaVersion.VERSION_1_8
    targetCompatibility JavaVersion.VERSION_1_8
  }
}
```

本文引用了以下博客
```
http://blog.csdn.net/xieyupeng520/article/details/47804481
```
```
http://news.oneapm.com/java-8-oneapm-lambda/
```